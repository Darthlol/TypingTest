from random import choice, randrange
import sys
import time
import pymorphy2

from PyQt5 import QtCore
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QInputDialog, QMessageBox, QPushButton, QAction, QMenu
from gui import Ui_MainWindow, Ui_Form


class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.pushButton = None
        self.exit_act = QAction("Выход", self, shortcut="Ctrl+Q", triggered=self.close)
        self.settings_act = QAction("Настройки", self, shortcut="Ctrl+D", triggered=self.open_settings)
        self.file_menu = QMenu("Файл", self)
        self.file_menu.addAction(self.exit_act)
        self.file_menu.addAction(self.settings_act)
        self.menuBar().addMenu(self.file_menu)
        self.settings = SettingsWindow()
        self.settings.stats.clicked.connect(self.show_stats)
        self.settings.buttonBox.accepted.connect(self.save_settings)
        self.settings.buttonBox.rejected.connect(self.settings.close)
        self.open_settings()

    def show_stats(self):
        pass

    def save_settings(self):
        self.diff = self.settings.diff.currentText()
        self.mode = self.settings.mode.currentText()
        self.lang = self.settings.lang.currentText()
        self.res = self.settings.res.currentText()
        self.listWidget.clear()
        self.lineEdit.clear()
        self.setup()
        self.settings.close()

    def setup(self):
        if self.lang == 'Русский' and self.diff == 'Легко':
            self.filename = './words/common_rus_words.txt'
        elif self.lang == 'Русский' and self.diff == 'Сложно':
            self.filename = './words/rus_words.txt'
        if self.lang == 'Английский' and self.diff == 'Легко':
            self.filename = './words/common_eng_words.txt'
        if self.lang == 'Английский' and self.diff == 'Сложно':
            self.filename = './words/eng_words.txt'
        f = open(self.filename, "r", encoding="utf8")
        self.words = f.readlines()
        f.close()
        self.total_words_count = 0
        self.right_words_count = 0
        self.total_symbols_count = 0
        self.right_symbols_count = 0
        self.word_list = [choice(self.words).strip() for _ in range(6)]
        self.listWidget.clear()
        self.listWidget.addItem('                         ' + '   '.join(self.word_list))
        self.lineEdit.textEdited.connect(self.CheckWord)
        self.flag = True
        if self.mode == 'Подсчет аккуратности':
            self.pushButton = QPushButton(self.centralwidget)
            self.pushButton.setGeometry(QtCore.QRect(160, 90, 141, 51))
            self.pushButton.setObjectName("pushButton")
            self.pushButton.setText('Завершить')
            self.pushButton.clicked.connect(self.show_results)
            self.pushButton.show()
            self.update()
        elif self.mode == 'Ввод до первой ошибки':
            if self.pushButton:
                self.pushButton.hide()
                self.update()

    def CheckWord(self):
        if self.flag:
            self.flag = False
            self.time = time.time()
        if ' ' in self.lineEdit.text():
            self.current_input = self.lineEdit.text()[:-1]
            self.word = self.word_list.pop(0)
            self.total_words_count += 1
            self.total_symbols_count += len(self.current_input)
            if self.current_input == self.word:
                self.lineEdit.clear()
                self.word_list += [choice(self.words).strip()]
                self.listWidget.clear()
                self.right_words_count += 1
                self.right_symbols_count += len(self.current_input)
                self.listWidget.addItem('                         ' + '   '.join(self.word_list))
            else:
                if self.mode == 'Ввод до первой ошибки':
                    self.show_results()
                else:
                    self.lineEdit.clear()
                    self.word_list = [self.word] + self.word_list

    def open_settings(self):
        self.settings.show()

    def show_results(self):
        self.mistake_time = time.time()
        if self.flag:
            self.time = self.mistake_time
        self.total_time = round(self.mistake_time - self.time)
        try:
            if self.total_words_count == 0:
                raise ValueError("Сначала введите слово!")
            if self.total_time == 0:
                raise ValueError("Слишком быстро!")
            if self.pushButton:
                self.pushButton.hide()
                self.update()
            self.lineEdit.clear()
            self.w = pymorphy2.MorphAnalyzer().parse('слово')[0].make_agree_with_number(self.right_words_count).word
            self.w2 = pymorphy2.MorphAnalyzer().parse('секунда')[0].inflect({'accs', 'plur'}).make_agree_with_number(self.total_time).word
            self.result_text = f'Вы ввели {self.right_words_count} {self.w} без ошибок за {self.total_time} {self.w2}\n'
            if self.res == 'WPM (слова в минуту)':
                self.accuracy = round(self.right_words_count / self.total_words_count * 100)
                self.wpm = self.right_words_count * 60 // self.total_time
                self.result_text += f'Ваша скорость составила {self.wpm} wpm\n'
            elif self.res == 'CPM (символы в минуту)':
                self.accuracy = round(self.right_symbols_count / self.total_symbols_count * 100)
                self.cpm = self.right_symbols_count * 60 // self.total_time
                self.result_text += f'Ваша скорость составила {self.cpm} cpm\n'
            if self.mode == 'Подсчет аккуратности':
                self.result_text += f'Ваша аккуратность составила {self.accuracy}%\n'
            self.result_text += 'Начать заново?'
            box = QMessageBox()
            box.setIcon(QMessageBox.Information)
            box.setText(self.result_text)
            box.setWindowTitle("Результат")
            box.setStandardButtons(QMessageBox.Yes|QMessageBox.No)
            yes = box.button(QMessageBox.Yes)
            yes.setText('Да')
            no = box.button(QMessageBox.No)
            no.setText('Нет')
            box.exec_()
            if box.clickedButton() == yes:
                self.listWidget.clear()
                self.lineEdit.clear()
                self.setup()
            elif box.clickedButton() == no:
                self.close()
        except ValueError as e:
            self.listWidget.clear()
            self.listWidget.addItem(f"Ошибка! {e}")

class SettingsWindow(QWidget, Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


if __name__ == '__main__':
    if hasattr(QtCore.Qt, 'AA_EnableHighDpiScaling'):
        QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
    if hasattr(QtCore.Qt, 'AA_UseHighDpiPixmaps'):
        QApplication.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    ex = MainWindow()
    ex.show()
    sys.exit(app.exec_())
