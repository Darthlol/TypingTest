from random import choice
import sys
import time
import pymorphy2
import sqlite3

from PyQt5 import QtCore
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QMessageBox, QPushButton, QAction, QMenu
from gui import Ui_MainWindow, Ui_Form, Ui_Form2


class MainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        self.LoginWindow = LoginWindow(self)
        self.LoginWindow.show()
        super().__init__()
        self.setupUi(self)
        self.pushButton = None
        self.exit_act = QAction("Выход", self, shortcut="Ctrl+Q", triggered=self.close)
        self.settings_act = QAction("Настройки", self, shortcut="Ctrl+D", triggered=self.open_settings)
        self.file_menu = QMenu("Файл", self)
        self.file_menu.addAction(self.exit_act)
        self.file_menu.addAction(self.settings_act)
        self.menuBar().addMenu(self.file_menu)
        self.settings = SettingsWindow()
        self.settings.buttonBox.accepted.connect(self.save_settings)
        self.settings.buttonBox.rejected.connect(self.settings.close)

    def set_user(self, username):
        self.username = username
        con = sqlite3.connect("users.sqlite")
        cur = con.cursor()
        self.mode = cur.execute(f"""SELECT Mode FROM Users
WHERE Username = "{username}"
""").fetchone()[0]
        self.diff = cur.execute(f"""SELECT Diff FROM Users
WHERE Username = "{username}"
""").fetchone()[0]
        self.lang = cur.execute(f"""SELECT Lang FROM Users
WHERE Username = "{username}"
""").fetchone()[0]
        self.res = cur.execute(f"""SELECT Res FROM Users
WHERE Username = "{username}"
""").fetchone()[0]
        if None in [self.mode, self.diff, self.lang, self.res]:
            self.settings.show()
        else:
            self.settings.mode.setCurrentText(self.mode)
            self.settings.diff.setCurrentText(self.diff)
            self.settings.lang.setCurrentText(self.lang)
            self.settings.res.setCurrentText(self.res)
            self.setup()
            self.show()
        self.get_record()

    def get_record(self):
        con = sqlite3.connect("users.sqlite")
        cur = con.cursor()
        if self.res == 'WPM (слова в минуту)':
            rec = cur.execute(f"""SELECT BestWPM FROM Users
        WHERE Username = "{self.username}"
        """).fetchone()[0]
            if rec:
                self.settings.listWidget.clear()
                self.settings.listWidget.addItem(f'Ваш рекорд - {rec} WPM')
            else:
                self.settings.listWidget.clear()
                self.settings.listWidget.addItem(f'У вас пока нет рекорда в WPM')
        elif self.res == 'CPM (символы в минуту)':
            rec = cur.execute(f"""SELECT BestCPM FROM Users
        WHERE Username = "{self.username}"
        """).fetchone()[0]
            if rec:
                self.settings.listWidget.clear()
                self.settings.listWidget.addItem(f'Ваш рекорд - {rec} CPM')
            else:
                self.settings.listWidget.clear()
                self.settings.listWidget.addItem(f'У вас пока нет рекорда в CPM')
        con.close()
        
    def save_settings(self):
        con = sqlite3.connect("users.sqlite")
        cur = con.cursor()
        self.diff = self.settings.diff.currentText()
        self.mode = self.settings.mode.currentText()
        self.lang = self.settings.lang.currentText()
        self.res = self.settings.res.currentText()
        cur.execute(f'''UPDATE Users
SET Mode = '{self.mode}',
Diff = '{self.diff}',
Lang = '{self.lang}',
Res = '{self.res}'
WHERE Username = '{self.username}'
''')
        self.get_record()
        self.listWidget.clear()
        self.lineEdit.clear()
        self.setup()
        self.settings.close()
        con.commit()
        con.close()
        self.show()

    def setup(self):
        if self.lang == 'Русский' and self.diff == 'Легко':
            self.filename = './words/common_rus_words.txt'
        elif self.lang == 'Русский' and self.diff == 'Сложно':
            self.filename = './words/rus_words.txt'
        if self.lang == 'Английский' and self.diff == 'Легко':
            self.filename = './words/common_eng_words.txt'
        if self.lang == 'Английский' and self.diff == 'Сложно':
            self.filename = './words/eng_words.txt'
        f = open(self.filename, "r", encoding="utf8")
        self.words = f.readlines()
        f.close()
        self.total_words_count = 0
        self.right_words_count = 0
        self.total_symbols_count = 0
        self.right_symbols_count = 0
        self.word_list = [choice(self.words).strip() for _ in range(6)]
        self.listWidget.clear()
        self.listWidget.addItem('                         ' + '   '.join(self.word_list))
        self.lineEdit.textEdited.connect(self.check_word)
        self.flag = True
        if self.mode == 'Подсчет аккуратности':
            self.pushButton = QPushButton(self.centralwidget)
            self.pushButton.setGeometry(QtCore.QRect(160, 90, 141, 51))
            self.pushButton.setObjectName("pushButton")
            self.pushButton.setText('Завершить')
            self.pushButton.clicked.connect(self.show_results)
            self.pushButton.show()
            self.update()
        elif self.mode == 'Ввод до первой ошибки':
            if self.pushButton:
                self.pushButton.hide()
                self.update()

    def check_word(self):
        if self.flag:
            self.flag = False
            self.time = time.time()
        if ' ' in self.lineEdit.text():
            self.current_input = self.lineEdit.text()[:-1]
            self.word = self.word_list.pop(0)
            self.total_words_count += 1
            self.total_symbols_count += len(self.current_input)
            if self.current_input == self.word:
                self.lineEdit.clear()
                self.word_list += [choice(self.words).strip()]
                self.listWidget.clear()
                self.right_words_count += 1
                self.right_symbols_count += len(self.current_input)
                self.listWidget.addItem('                         ' + '   '.join(self.word_list))
            else:
                if self.mode == 'Ввод до первой ошибки':
                    self.show_results()
                else:
                    self.lineEdit.clear()
                    self.word_list = [self.word] + self.word_list

    def open_settings(self):
        self.settings.show()

    def show_results(self):
        self.mistake_time = time.time()
        if self.flag:
            self.time = self.mistake_time
        self.total_time = round(self.mistake_time - self.time)
        try:
            if self.total_words_count == 0:
                raise ValueError("Сначала введите слово!")
            if self.total_time == 0:
                raise ValueError("Слишком быстро!")
            if self.pushButton:
                self.pushButton.hide()
                self.update()
            self.lineEdit.clear()
            if self.res == 'WPM (слова в минуту)':
                self.w = pymorphy2.MorphAnalyzer().parse('слово')[0].make_agree_with_number(self.right_words_count).word
            elif self.res == 'CPM (символы в минуту)':
                self.w = pymorphy2.MorphAnalyzer().parse('символ')[0].make_agree_with_number(self.right_words_count).word
            self.w2 = pymorphy2.MorphAnalyzer().parse('секунда')[0].inflect({'accs', 'plur'})
            self.w2 = self.w2.make_agree_with_number(self.total_time).word
            self.result_text = f'Вы ввели {self.right_words_count} {self.w} без ошибок за {self.total_time} {self.w2}\n'
            if self.res == 'WPM (слова в минуту)':
                self.accuracy = round(self.right_words_count / self.total_words_count * 100)
                self.wpm = self.right_words_count * 60 // self.total_time
                con = sqlite3.connect("users.sqlite")
                cur = con.cursor()
                max_wpm = cur.execute(f"""SELECT BestWPM FROM Users
WHERE Username = "{self.username}"
""").fetchone()[0]
                if max_wpm:
                    if max_wpm < self.wpm:
                        cur.execute(f'''UPDATE Users
SET BestWPM = {self.wpm}
WHERE Username = '{self.username}'
''')
                        self.settings.listWidget.clear()
                        self.settings.listWidget.addItem(f'Ваш рекорд - {self.wpm} WPM')
                else:
                    cur.execute(f'''UPDATE Users
SET BestWPM = {self.wpm}
WHERE Username = '{self.username}'
''')
                    self.settings.listWidget.clear()
                    self.settings.listWidget.addItem(f'Ваш рекорд - {self.wpm} WPM')
                con.commit()
                con.close()
                self.result_text += f'Ваша скорость составила {self.wpm} wpm\n'
            elif self.res == 'CPM (символы в минуту)':
                self.accuracy = round(self.right_symbols_count / self.total_symbols_count * 100)
                self.cpm = self.right_symbols_count * 60 // self.total_time
                con = sqlite3.connect("users.sqlite")
                cur = con.cursor()
                max_cpm = cur.execute(f"""SELECT BestCPM FROM Users
WHERE Username = "{self.username}"
""").fetchone()[0]
                if max_cpm:
                    if max_cpm < self.cpm:
                        cur.execute(f'''UPDATE Users
SET BestCPM = {self.cpm}
WHERE Username = '{self.username}'
''')
                        self.settings.listWidget.clear()
                        self.settings.listWidget.addItem(f'Ваш рекорд - {self.cpm} CPM')
                else:
                    cur.execute(f'''UPDATE Users
SET BestCPM = {self.cpm}
WHERE Username = '{self.username}'
''')
                    self.settings.listWidget.clear()
                    self.settings.listWidget.addItem(f'Ваш рекорд - {self.cpm} CPM')
                con.commit()
                con.close()
                self.result_text += f'Ваша скорость составила {self.cpm} cpm\n'
            if self.mode == 'Подсчет аккуратности':
                self.result_text += f'Ваша аккуратность составила {self.accuracy}%\n'
            self.result_text += 'Начать заново?'
            box = QMessageBox()
            box.setIcon(QMessageBox.Information)
            box.setText(self.result_text)
            box.setWindowTitle("Результат")
            box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
            yes = box.button(QMessageBox.Yes)
            yes.setText('Да')
            no = box.button(QMessageBox.No)
            no.setText('Нет')
            box.exec_()
            if box.clickedButton() == yes:
                self.listWidget.clear()
                self.lineEdit.clear()
                self.setup()
            elif box.clickedButton() == no:
                self.close()
        except ValueError as e:
            self.listWidget.clear()
            self.listWidget.addItem(f"Ошибка! {e}")


class SettingsWindow(QWidget, Ui_Form):
    def __init__(self):
        super().__init__()
        self.setupUi(self)


class LoginWindow(QWidget, Ui_Form2):
    def __init__(self, parent):
        super().__init__()
        self.MainWindow = parent
        self.setupUi(self)
        self.login_button.clicked.connect(self.login)

    def login(self):
        try:
            if self.check_password():
                self.MainWindow.set_user(self.username)
                self.close()
        except ValueError as e:
            _translate = QtCore.QCoreApplication.translate
            self.password_edit.clear()
            self.label_2.setText(_translate("Form",
                                            f"""<html><head/><body><p><span style=\" font-size:14pt; 
                                            font-weight:600;\">{e}</span></p><p><span style=\" font-size:14pt;
                                            \"><br/></span></p></body></html>"""))

    def check_password(self):
        self.username = self.username_edit.text()
        self.password = self.password_edit.text()
        if self.username.isdigit() or self.password.isdigit() or self.username == '' or self.password == '':
                :
            raise ValueError('Используйте буквы!')
        con = sqlite3.connect("users.sqlite")
        cur = con.cursor()
        if (self.username,) in cur.execute("""SELECT Username FROM Users"""):
            psw = cur.execute(f"""SELECT Password FROM Users
WHERE Username = "{self.username}"
""").fetchone()
            if (self.password,) == psw:
                con.close()
                return True
            else:
                con.close()
                raise ValueError('Неверный пароль!')
        else:
            _translate = QtCore.QCoreApplication.translate
            cur.execute(f'''INSERT INTO Users(Username,Password) VALUES ("{self.username}","{self.password}")''')
            con.commit()
            self.label_2.setText(_translate("Form",
                                            """<html><head/><body><p><span style=\" 
                                            font-size:14pt; font-weight:600;\">Повторите пароль</span></p><p>
                                            <span style=\" font-size:14pt;\"><br/></span></p></body></html>"""))
            self.password_edit.clear()
            return False


if __name__ == '__main__':
    if hasattr(QtCore.Qt, 'AA_EnableHighDpiScaling'):
        QApplication.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
    if hasattr(QtCore.Qt, 'AA_UseHighDpiPixmaps'):
        QApplication.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    MainApp = MainWindow()
    sys.exit(app.exec_())
